'use strict';
/* Rendering, page changes and events */
/* ---------- render ---------- */
function draw(){
  var p=route.split(':'),name=p[0],arg=p[1];
  head.innerHTML=headerHTML(name);
  main.innerHTML=(V[name]||V.home)(arg);
  foot.innerHTML=name==='contact'?footerHTML():'';
  $('#fab').href=waLink();
  setMeta(name,arg);
  if(name==='book')initBook();
}
function go(r,opts){
  var name=r.split(':')[0],sec=(opts&&opts.sec)||'';
  if(PAGEOF[name]){sec=sec||SECID[name]||name;name=PAGEOF[name];r=name}
  route=r;ui.menu=false;ui.resch=null;ui.del='';
  if(name!=='book'){ui.done=null;ui.preService='';ui.chal=null}
  if(name==='book'&&!(opts&&opts.keep)){S.stats.bookView++}
  if(name!=='admin'){S.stats.views[name]=(S.stats.views[name]||0)+1}
  save();draw();
  main.classList.remove('page-in');void main.offsetWidth;main.classList.add('page-in');
  var el=sec?document.getElementById(sec):null;
  if(el){var pv=el.querySelector('details.q');if(sec==='privacy'&&pv)pv.open=true;el.scrollIntoView()}else window.scrollTo(0,0);
}

/* ---------- events ---------- */
document.addEventListener('click',function(e){
  var t=e.target.closest('[data-go],[data-act]');if(!t)return;
  if(t.id==='skip'){return}
  if(t.dataset.go){
    e.preventDefault();
    if(t.dataset.svc)ui.preService=t.dataset.svc;
    go(t.dataset.go,{sec:t.dataset.sec});return;
  }
  act(t.dataset.act,t);
});
document.addEventListener('pointerdown',function(e){
  var t=e.target.closest('.btn,nav.main a,.filters button,.admin-tabs button');if(!t)return;
  var r=t.getBoundingClientRect(),s=Math.max(r.width,r.height)*2,sp=document.createElement('span');
  sp.className='rip';sp.style.cssText='width:'+s+'px;height:'+s+'px;left:'+(e.clientX-r.left-s/2)+'px;top:'+(e.clientY-r.top-s/2)+'px';
  t.appendChild(sp);setTimeout(function(){sp.remove()},650);
});
$('#skip').addEventListener('click',function(e){e.preventDefault();main.focus()});

function act(a,t){
  var id=t.dataset.id;
  if(a==='menu'){ui.menu=!ui.menu;draw();return}
  if(a==='copy'){copy(t.dataset.text);return}
  if(a==='book-again'){ui.done=null;ui.chal=null;draw();return}
  if(a==='logout'){ui.auth=false;draw();return}
  if(a==='reset'){S=seed();save();toast('Demo data restored');draw();return}
  if(a==='tab'){ui.tab=t.dataset.tab;ui.resch=null;draw();return}
  if(a==='filter'){ui.f=t.dataset.f;rerenderAdmin();return}
  if(a==='resch'){ui.resch=ui.resch===id?null:id;rerenderAdmin();return}
  if(a==='resch-cancel'){ui.resch=null;rerenderAdmin();return}
  if(a==='resch-save'){
    var ap=S.appts.find(function(x){return x.id===id}),d=$('#rs-date').value,tm=$('#rs-time').value;
    if(!d||!tm){toast('Choose a date and a free time first');return}
    ap.date=d;ap.time=tm;logNote(ap,msgMoved(ap));ui.resch=null;save();toast('Appointment moved. Patient message logged.');rerenderAdmin();return;
  }
  if(a==='remind'){var r=S.appts.find(function(x){return x.id===id});logNote(r,msgReminder(r));save();toast('Reminder logged for '+r.name);return}
  if(a==='add'){var k=t.dataset.kind,it=BLANK[k]();S[k].unshift(it);ui.open=k+':'+it.id;save();draw();return}
  if(a==='del'){
    var key=t.dataset.kind+':'+id;
    if(ui.del!==key){ui.del=key;ui.open=key;draw();return}
    S[t.dataset.kind]=S[t.dataset.kind].filter(function(x){return x.id!==id});ui.del='';ui.open='';save();toast('Deleted');draw();return;
  }
}
function rerenderAdmin(){var b=$('#admin-body');if(b){b.innerHTML=adminTab()}else{draw()}}

document.addEventListener('change',function(e){
  var t=e.target;
  if(t.dataset&&t.dataset.change==='status'){
    var a=S.appts.find(function(x){return x.id===t.dataset.id});a.status=t.value;
    if(t.value==='Confirmed')logNote(a,msgConfirmed(a));
    if(t.value==='Cancelled')logNote(a,msgCancelled(a));
    save();toast('Status set to '+t.value+(t.value==='Confirmed'||t.value==='Cancelled'?'. Patient message logged.':''));
    var h=$('.admin-tabs button[data-tab="appts"]');if(h)h.textContent='Appointments'+(pending()?' ('+pending()+')':'');
    return;
  }
  if(t.id==='f-date'||t.id==='f-dentist'){fillTimes();return}
  if(t.id==='rs-date'){
    var ap=S.appts.find(function(x){return x.id===ui.resch});
    $('#rs-time').innerHTML=rsOpts(slotsFor(t.value,ap.dentist,ap.id),'');return;
  }
});
document.addEventListener('input',function(e){
  if(e.target.id==='ap-search'){ui.q=e.target.value;$('#ap-list').innerHTML=apList()}
});

var H={};
document.addEventListener('submit',function(e){
  var f=e.target.closest('form[data-form]');if(!f)return;
  e.preventDefault();var h=H[f.dataset.form];if(h)h(f);
});

H.login=function(){
  var err=$('#e-login');
  if(Date.now()<ui.lockUntil){err.textContent='Too many attempts. Wait a few seconds and try again.';return}
  if($('#u').value.trim()==='admin'&&$('#p').value==='smile2026'){ui.auth=true;ui.fails=0;ui.tab='overview';draw();return}
  ui.fails++;
  if(ui.fails>=3){ui.lockUntil=Date.now()+30000;ui.fails=0;err.textContent='Locked for 30 seconds after three wrong attempts.';setTimeout(function(){if(route==='admin'&&!ui.auth)draw()},30500);return}
  err.textContent='Username or password is incorrect. '+(3-ui.fails)+' attempt'+(3-ui.fails===1?'':'s')+' left.';
};
H.edit=function(f){
  var kind=f.dataset.kind,item=S[kind].find(function(x){return x.id===f.dataset.id}),fd=new FormData(f);
  FIELDS[kind].forEach(function(fl){
    var v;
    if(fl.t==='days'){v=fd.getAll('days').map(Number)}
    else{v=(fd.get(fl.k)||'').toString();
      if(fl.t==='lines')v=v.split('\n').map(function(s){return s.trim()}).filter(Boolean);
      else if(fl.t==='number')v=Math.max(0,Number(v)||0);
      else v=v.trim()}
    item[fl.k]=v;
  });
  if(kind==='reviews')item.rating=Math.min(5,Math.max(1,item.rating||5));
  if(kind==='dentists'&&toMin(item.end)<=toMin(item.start)){toast('End time must be after start time');return}
  ui.open=kind+':'+item.id;ui.del='';save();toast('Saved');draw();
};
H.book=function(f){
  var fd=new FormData(f),v=function(k){return (fd.get(k)||'').toString().trim()};
  if(v('website')){ui.done={name:'there',date:today(),time:'09:00',ref:'CWD-0000'};draw();return}
  var now=Date.now();ui.submits=ui.submits.filter(function(x){return now-x<60000});
  var E={};
  var name=v('name');if(name.length<2||!/[A-Za-z஀-௿]/.test(name))E.name='Enter your full name.';
  var ph=v('phone');if(!/^(\+91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}$/.test(ph))E.phone='Enter a 10-digit mobile number, for example 98765 43210.';
  var em=v('email');if(em&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em))E.email='Enter a valid email address or leave it empty.';
  var sv=v('service');if(!sv)E.service='Choose a treatment.';
  var dt=v('date');
  if(!dt)E.date='Choose a date.';
  else if(dt<today())E.date='Choose today or a later date.';
  else if(parse(dt).getDay()===0)E.date='We are closed on Sundays. Choose another day.';
  var tm=v('time'),dnt=v('dentist')||'any';
  if(!tm)E.time='Choose a time.';
  else if(dt&&!E.date&&slotsFor(dt,dnt).indexOf(tm)<0)E.time='That time was just taken. Choose another.';
  if(Number(v('human'))!==ui.chal.a+ui.chal.b)E.human='That answer is not right. Try again.';
  if(!fd.get('consent'))E.consent='Please agree so we can use your details to book you in.';
  if(!E.human&&now-ui.bookStart<3000)E.human='Please review your details and submit again.';
  if(!Object.keys(E).length&&ui.submits.length>=3)E.human='Too many requests in a minute. Please wait and try again.';
  ['name','phone','email','service','date','time','human','consent'].forEach(function(k){setErr(k,E[k])});
  var keys=Object.keys(E);
  if(keys.length){var el=$('#f-'+keys[0]);if(el)el.focus();return}
  ui.submits.push(now);
  var a={id:'a'+uid(),ref:'CWD-'+(S.seq++),name:name,phone:ph,email:em,service:sv,dentist:dnt,date:dt,time:tm,status:'Pending',note:v('note'),created:now};
  S.appts.push(a);logNote(a,msgReceived(a));S.stats.bookings++;save();
  ui.done=a;ui.chal=null;draw();window.scrollTo(0,0);
};

/* ---------- start ---------- */
(function(){
  var h=(location.hash||'').slice(1);
  var known=['home','about','book','contact','admin'];
  if(known.indexOf(h)>-1)route=h;
  else if(PAGEOF[h]){route=PAGEOF[h];setTimeout(function(){var el=document.getElementById(SECID[h]||h);if(el)el.scrollIntoView()},60)}
  S.stats.views[route]=(S.stats.views[route]||0)+(route==='admin'?0:1);
  if(route==='book')S.stats.bookView++;
  save();draw();
})();
