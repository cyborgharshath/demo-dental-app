'use strict';
/* Book appointment page and form */
/* ---------- booking ---------- */
V.book=function(){
  if(!ui.chal)ui.chal={a:2+Math.floor(Math.random()*7),b:2+Math.floor(Math.random()*7)};
  var min=today(),maxd=new Date();maxd.setDate(maxd.getDate()+60);
  var sv=ui.preService;
  return pageHead('Request an appointment','Choose a time that suits you. We confirm by WhatsApp or phone during working hours.')+
  '<section class="band"><div class="wrap book-grid"><div id="book-wrap" class="card" style="padding:1.5rem">'+(ui.done?doneHTML(ui.done):
  '<form id="book-form" data-form="book" novalidate class="stack"><div class="form-grid">'+
  '<div class="field"><label for="f-name">Full name</label><input id="f-name" name="name" autocomplete="name" aria-describedby="e-name"><span class="err" id="e-name"></span></div>'+
  '<div class="field"><label for="f-phone">Mobile number</label><input id="f-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="98765 43210" aria-describedby="e-phone"><span class="err" id="e-phone"></span></div>'+
  '<div class="field"><label for="f-email">Email <span class="small">(optional)</span></label><input id="f-email" name="email" type="email" autocomplete="email" aria-describedby="e-email"><span class="err" id="e-email"></span></div>'+
  '<div class="field"><label for="f-service">Treatment</label><select id="f-service" name="service" aria-describedby="e-service"><option value="">Choose a treatment</option>'+S.services.map(function(s){return '<option value="'+s.id+'"'+(sv===s.id?' selected':'')+'>'+esc(s.name)+'</option>'}).join('')+'</select><span class="err" id="e-service"></span></div>'+
  '<div class="field"><label for="f-dentist">Dentist</label><select id="f-dentist" name="dentist"><option value="any">First available</option>'+S.dentists.map(function(d){return '<option value="'+d.id+'">'+esc(d.name)+'</option>'}).join('')+'</select></div>'+
  '<div class="field"><label for="f-date">Preferred date</label><input id="f-date" name="date" type="date" min="'+min+'" max="'+iso(maxd)+'" aria-describedby="e-date"><span class="err" id="e-date"></span></div>'+
  '<div class="field"><label for="f-time">Preferred time</label><select id="f-time" name="time" aria-describedby="e-time"><option value="">Pick a date first</option></select><span class="err" id="e-time"></span></div></div>'+
  '<div class="field"><label for="f-note">Short note <span class="small">(optional, no medical details please)</span></label><textarea id="f-note" name="note" rows="2" maxlength="140"></textarea></div>'+
  '<div class="hp" aria-hidden="true"><label for="f-site">Leave this field empty</label><input id="f-site" name="website" tabindex="-1" autocomplete="off"></div>'+
  '<div class="field" style="max-width:260px"><label for="f-human">Quick check: what is '+ui.chal.a+' + '+ui.chal.b+'?</label><input id="f-human" name="human" inputmode="numeric" autocomplete="off" aria-describedby="e-human"><span class="err" id="e-human"></span></div>'+
  '<div><label class="check"><input type="checkbox" id="f-consent" name="consent"><span>I agree that Clearwater Dental may use these details to arrange my appointment. See the '+lk('privacy','privacy policy')+'.</span></label><span class="err" id="e-consent"></span></div>'+
  '<div><button class="btn" type="submit">Request appointment</button></div></form>')+'</div>'+
  '<aside class="stack"><div class="card"><h3>What happens next</h3><ol class="steps"><li><div>We receive your request and send a short confirmation of receipt.</div></li><li><div>Our team confirms the slot by WhatsApp or phone.</div></li><li><div>You get a reminder the day before.</div></li></ol></div>'+
  '<div class="card"><h3>Prefer to talk?</h3><p><a href="tel:'+C.tel+'"><strong>'+C.phone+'</strong></a></p><a class="btn wa sm" href="'+waLink()+'" target="_blank" rel="noopener">WhatsApp us</a><p class="small">Mon to Sat, 9 AM to 7 PM. For dental pain, message us and we will find a same-day slot.</p></div></aside></div></section>'+seeMore('contact','Contact us','Directions, opening hours and every way to reach us.');
};
function fillTimes(){
  var d=$('#f-date'),t=$('#f-time'),dn2=$('#f-dentist');if(!d||!t)return;
  if(!d.value){t.innerHTML='<option value="">Pick a date first</option>';return}
  var prev=t.value,sl=slotsFor(d.value,dn2.value);
  t.innerHTML=sl.length?'<option value="">Choose a time</option>'+sl.map(function(x){return '<option value="'+x+'"'+(x===prev?' selected':'')+'>'+fmtTime(x)+'</option>'}).join(''):'<option value="">No free slots that day</option>';
}
function setErr(k,m){var e=$('#e-'+k),f=$('#f-'+k);if(e)e.textContent=m||'';if(f){if(m){f.setAttribute('aria-invalid','true');f.classList.remove('shake');void f.offsetWidth;f.classList.add('shake')}else f.removeAttribute('aria-invalid')}}
function doneHTML(a){
  return '<div class="stack"><span class="chip s-Confirmed" style="justify-self:start">Request received</span><h2>Thank you, '+esc(first(a.name))+'.</h2><p>Your request for <strong>'+fmtDate(a.date)+' at '+fmtTime(a.time)+'</strong> is in. Reference <strong>'+a.ref+'</strong>.</p>'+
  '<div class="preview"><p class="small" style="margin-bottom:.3rem"><strong>Message we send you</strong> (preview). It contains no treatment or health details.</p><p>'+esc(msgReceived(a))+'</p></div>'+
  '<div class="row"><a class="btn wa" href="'+waLink('Hello Clearwater Dental, my booking reference is '+a.ref+'.')+'" target="_blank" rel="noopener">Message us on WhatsApp</a><button class="btn ghost" type="button" data-act="book-again">Make another request</button></div></div>';
}
function initBook(){
  ui.bookStart=Date.now();
  var d=$('#f-date');if(d){fillTimes()}
}
