'use strict';
/* Staff login and dashboard */
/* ---------- admin ---------- */
V.admin=function(){return ui.auth?adminShell():loginHTML()};
function loginHTML(){
  var locked=Date.now()<ui.lockUntil;
  return pageHead('Staff login','Authorised clinic staff only.')+
  '<section class="band"><div class="wrap"><div class="login stack"><form class="card" data-form="login" novalidate><div class="field"><label for="u">Username</label><input id="u" name="u" autocomplete="username"></div><div class="field"><label for="p">Password</label><input id="p" name="p" type="password" autocomplete="current-password"></div><span class="err" id="e-login"></span><button class="btn" type="submit"'+(locked?' disabled':'')+'>Sign in</button></form><div class="note"><strong>Demo access:</strong> username <code>admin</code>, password <code>smile2026</code>. The live site uses real accounts and server-side checks. After three wrong attempts the form locks for 30 seconds.</div></div></div></section>';
}
var TABS=[['overview','Overview'],['appts','Appointments'],['dentists','Dentists'],['services','Services'],['content','Content'],['reqs','Requirements']];
function adminShell(){
  return '<section class="band" style="padding-top:2rem"><div class="wrap"><div class="row" style="justify-content:space-between;margin-bottom:1rem"><div><p class="eyebrow" style="margin:0">Staff area</p><h1 style="font-size:clamp(1.7rem,3.4vw,2.3rem)">Clinic dashboard</h1></div><div class="row"><button class="btn ghost sm" type="button" data-act="reset">Reset demo data</button><button class="btn ghost sm" type="button" data-act="logout">Sign out</button></div></div>'+
  '<div class="admin-tabs" role="tablist" aria-label="Dashboard sections">'+TABS.map(function(t){return '<button type="button" role="tab" data-act="tab" data-tab="'+t[0]+'" aria-selected="'+(ui.tab===t[0])+'">'+t[1]+(t[0]==='appts'&&pending()?' ('+pending()+')':'')+'</button>'}).join('')+'</div><div id="admin-body">'+adminTab()+'</div></div></section>';
}
var pending=function(){return S.appts.filter(function(a){return a.status==='Pending'}).length};
function adminTab(){return ({overview:tabOverview,appts:tabAppts,dentists:tabDentists,services:tabServices,content:tabContent,reqs:tabReqs})[ui.tab]()}
function apRow(a){return '<div class="li"><time>'+fmtTime(a.time)+'</time><div><strong>'+esc(a.name)+'</strong><br><span class="small">'+esc(sn(a.service))+' · '+esc(dn(a.dentist))+'</span></div><span class="chip s-'+a.status+'">'+a.status+'</span></div>'}
function tabOverview(){
  var t=today(),in7=wd(7);
  var td=S.appts.filter(function(a){return a.date===t&&a.status!=='Cancelled'}).sort(function(a,b){return a.time.localeCompare(b.time)});
  var up=S.appts.filter(function(a){return a.date>t&&a.date<=in7&&a.status!=='Cancelled'}).sort(function(a,b){return (a.date+a.time).localeCompare(b.date+b.time)});
  var ns=S.appts.filter(function(a){return a.status==='No-show'}).length;
  var v=S.stats.views,keys=Object.keys(v).sort(function(a,b){return v[b]-v[a]}).slice(0,6),mx=keys.length?v[keys[0]]:1;
  var conv=S.stats.bookView?Math.round(S.stats.bookings/S.stats.bookView*100):0;
  return '<div class="tiles"><div class="tile"><b>'+td.length+'</b>Today’s appointments</div><div class="tile'+(pending()?' attn':'')+'"><b>'+pending()+'</b>Pending requests</div><div class="tile"><b>'+up.length+'</b>Next 7 days</div><div class="tile"><b>'+ns+'</b>No-shows recorded</div></div>'+
  '<div class="grid g2" style="gap:1.5rem"><div><h3 style="margin-bottom:.8rem">Today</h3><div class="list">'+(td.length?td.map(apRow).join(''):'<p class="empty">No appointments today.</p>')+'</div><h3 style="margin:1.5rem 0 .8rem">Upcoming</h3><div class="list">'+(up.length?up.map(function(a){return '<div class="li"><time>'+fmtDate(a.date).split(',')[0]+' '+fmtTime(a.time).replace(' ','')+'</time><div><strong>'+esc(a.name)+'</strong><br><span class="small">'+esc(sn(a.service))+' · '+esc(dn(a.dentist))+'</span></div><span class="chip s-'+a.status+'">'+a.status+'</span></div>'}).join(''):'<p class="empty">Nothing booked in the next 7 days.</p>')+'</div></div>'+
  '<div class="stack"><div class="card"><h3>Messages sent</h3><p class="small">Simulated. No real messages leave this demo.</p>'+(S.notes.length?S.notes.slice(0,5).map(function(n){return '<div class="preview"><span class="small">'+new Date(n.t).toLocaleTimeString('en-IN',{hour:'numeric',minute:'2-digit'})+' to '+esc(n.to)+'</span><br>'+esc(n.text)+'</div>'}).join(''):'<p class="empty">No messages yet. Confirm or move an appointment to see one.</p>')+'</div>'+
  '<div class="card"><h3>Site activity</h3><p class="small">Cookie-free counts stored in this browser.</p><div class="bars">'+(keys.length?keys.map(function(k){return '<div class="bar-row"><span>'+esc(k)+'</span><span class="track"><span class="fill" style="width:'+Math.max(6,Math.round(v[k]/mx*100))+'%"></span></span><span>'+v[k]+'</span></div>'}).join(''):'<p class="small">Browse the public pages to see activity here.</p>')+'</div><p><strong>'+S.stats.bookings+'</strong> bookings from <strong>'+S.stats.bookView+'</strong> booking page views ('+conv+'%).</p></div></div></div>';
}
var STAT=['Pending','Confirmed','Completed','Cancelled','No-show'];
function tabAppts(){
  return '<div class="filters" role="group" aria-label="Filter by status">'+['All'].concat(STAT).map(function(s){return '<button type="button" data-act="filter" data-f="'+s+'" aria-pressed="'+(ui.f===s)+'">'+s+'</button>'}).join('')+'<label class="sr" for="ap-search">Search appointments</label><input id="ap-search" type="search" placeholder="Search name, phone or ref" value="'+esc(ui.q)+'"></div><div id="ap-list">'+apList()+'</div>';
}
function apList(){
  var list=S.appts.slice().sort(function(a,b){return (a.date+a.time).localeCompare(b.date+b.time)});
  if(ui.f!=='All')list=list.filter(function(a){return a.status===ui.f});
  if(ui.q){var q=ui.q.toLowerCase();list=list.filter(function(a){return (a.name+' '+a.phone+' '+a.ref).toLowerCase().indexOf(q)>-1})}
  if(!list.length)return '<p class="empty">No appointments match.</p>';
  return '<div class="tw"><table><thead><tr><th>Ref</th><th>Patient</th><th>Treatment</th><th>Dentist</th><th>When</th><th>Status</th><th>Actions</th></tr></thead><tbody>'+list.map(function(a){
    var r='<tr><td>'+a.ref+'</td><td><strong>'+esc(a.name)+'</strong><br><span class="small">'+esc(a.phone)+'</span></td><td>'+esc(sn(a.service))+'</td><td>'+esc(dn(a.dentist))+'</td><td>'+fmtDate(a.date)+'<br>'+fmtTime(a.time)+'</td><td><label class="sr" for="st-'+a.id+'">Status for '+esc(a.name)+'</label><select id="st-'+a.id+'" data-change="status" data-id="'+a.id+'" style="min-width:8.5rem">'+STAT.map(function(s){return '<option'+(s===a.status?' selected':'')+'>'+s+'</option>'}).join('')+'</select></td><td><div class="row" style="gap:.4rem"><button class="btn ghost sm" type="button" data-act="resch" data-id="'+a.id+'">Reschedule</button>'+(a.status==='Confirmed'?'<button class="btn ghost sm" type="button" data-act="remind" data-id="'+a.id+'">Send reminder</button>':'')+'</div></td></tr>';
    if(ui.resch===a.id){
      var sl=slotsFor(a.date,a.dentist,a.id);
      r+='<tr><td colspan="7" style="background:var(--surface)"><div class="row"><label for="rs-date" class="lbl">New date</label><input id="rs-date" type="date" min="'+today()+'" value="'+a.date+'" style="width:auto"><label for="rs-time" class="lbl">New time</label><select id="rs-time" style="width:auto">'+rsOpts(sl,a.time)+'</select><button class="btn sm" type="button" data-act="resch-save" data-id="'+a.id+'">Save new time</button><button class="btn ghost sm" type="button" data-act="resch-cancel">Close</button></div></td></tr>';
    }
    return r;
  }).join('')+'</tbody></table></div>';
}
function rsOpts(sl,cur){return sl.length?sl.map(function(x){return '<option value="'+x+'"'+(x===cur?' selected':'')+'>'+fmtTime(x)+'</option>'}).join(''):'<option value="">No free slots</option>'}

/* generic editors */
var FIELDS={
  dentists:[{k:'name',l:'Name'},{k:'role',l:'Specialty'},{k:'qual',l:'Qualifications'},{k:'years',l:'Years of experience',t:'number'},{k:'bio',l:'Short bio',t:'area',r:3},{k:'days',l:'Working days',t:'days'},{k:'start',l:'Starts',t:'time'},{k:'end',l:'Ends',t:'time'}],
  services:[{k:'name',l:'Treatment name'},{k:'short',l:'One-line summary'},{k:'price',l:'Starting price (₹)',t:'number'},{k:'dur',l:'Typical time'},{k:'desc',l:'Description',t:'area',r:4},{k:'steps',l:'What to expect (one step per line)',t:'lines',r:4}],
  faqs:[{k:'q',l:'Question'},{k:'a',l:'Answer',t:'area',r:3}],
  reviews:[{k:'name',l:'Patient name (first name and initial)'},{k:'treat',l:'Treatment'},{k:'rating',l:'Rating (1 to 5)',t:'number'},{k:'text',l:'Review text',t:'area',r:3}],
  posts:[{k:'title',l:'Title'},{k:'cat',l:'Category'},{k:'date',l:'Date',t:'date'},{k:'excerpt',l:'Short summary'},{k:'body',l:'Article (one paragraph per line)',t:'lines',r:6}]
};
var TITLE={dentists:function(i){return i.name},services:function(i){return i.name},faqs:function(i){return i.q},reviews:function(i){return i.name+' ('+i.treat+')'},posts:function(i){return i.title}};
var BLANK={
  dentists:function(){return {id:uid(),name:'New dentist',role:'General Dentist',qual:'BDS',years:1,bio:'',days:[1,2,3,4,5],start:'09:00',end:'17:00',treats:['checkup']}},
  services:function(){return {id:uid(),name:'New treatment',short:'',price:0,dur:'30 min',desc:'',steps:[]}},
  faqs:function(){return {id:uid(),q:'New question',a:''}},
  reviews:function(){return {id:uid(),name:'Patient',treat:'Check-up and cleaning',rating:5,text:''}},
  posts:function(){return {id:uid(),title:'New article',date:today(),cat:'General',excerpt:'',body:[]}}
};
function fieldHTML(kind,item,f){
  var id='e-'+kind+'-'+item.id+'-'+f.k,v=item[f.k];
  if(f.t==='days')return '<div><span class="lbl">'+f.l+'</span><div class="daysel">'+DAYORDER.map(function(d){return '<label><input type="checkbox" name="days" value="'+d+'"'+(v.indexOf(d)>-1?' checked':'')+'>'+DAYN[d]+'</label>'}).join('')+'</div></div>';
  var lab='<label for="'+id+'" class="lbl">'+f.l+'</label>';
  if(f.t==='area')return '<div class="field">'+lab+'<textarea id="'+id+'" name="'+f.k+'" rows="'+(f.r||3)+'">'+esc(v)+'</textarea></div>';
  if(f.t==='lines')return '<div class="field">'+lab+'<textarea id="'+id+'" name="'+f.k+'" rows="'+(f.r||4)+'">'+esc(v.join('\n'))+'</textarea></div>';
  return '<div class="field">'+lab+'<input id="'+id+'" name="'+f.k+'" type="'+(f.t||'text')+'" value="'+esc(v)+'"></div>';
}
function editor(kind,heading){
  var items=S[kind],key;
  return '<div class="row" style="justify-content:space-between;margin-bottom:.8rem"><h3>'+heading+' ('+items.length+')</h3><button class="btn sm" type="button" data-act="add" data-kind="'+kind+'">Add new</button></div>'+
  (items.length?items.map(function(it){
    key=kind+':'+it.id;
    return '<details class="ed"'+(ui.open===key?' open':'')+'><summary>'+esc(TITLE[kind](it))+'</summary><form data-form="edit" data-kind="'+kind+'" data-id="'+it.id+'">'+FIELDS[kind].map(function(f){return fieldHTML(kind,it,f)}).join('')+'<div class="row"><button class="btn sm" type="submit">Save changes</button><button class="btn danger sm" type="button" data-act="del" data-kind="'+kind+'" data-id="'+it.id+'">'+(ui.del===key?'Click again to delete':'Delete')+'</button></div></form></details>';
  }).join(''):'<p class="empty">Nothing here yet. Use Add new.</p>');
}
function tabDentists(){return '<div class="note" style="margin-bottom:1rem">Working days and hours set which time slots patients can book.</div>'+editor('dentists','Dentist profiles and working hours')}
function tabServices(){return editor('services','Treatments')}
function tabContent(){return editor('faqs','FAQs')+'<div style="height:1.5rem"></div>'+editor('reviews','Testimonials')+'<div style="height:1.5rem"></div>'+editor('posts','Blog posts')}
