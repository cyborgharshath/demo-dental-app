'use strict';
/* Clinic details and small helper functions */
var KEY='clearwater-dental-demo-v1';
var C={name:'Clearwater Dental',phone:'+91 90000 12345',tel:'+919000012345',wa:'919000012345',email:'hello@clearwaterdental.example',addr:'42 Lake View Road, Greenfield, 600001'};
var HOURS=[['Monday to Saturday','9:00 AM to 7:00 PM'],['Sunday','Closed']];
var DAYN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
var DAYORDER=[1,2,3,4,5,6,0];

/* ---------- helpers ---------- */
var $=function(s,r){return (r||document).querySelector(s)};
var esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var pad=function(n){return String(n).padStart(2,'0')};
var iso=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
var today=function(){return iso(new Date())};
var parse=function(s){var p=s.split('-').map(Number);return new Date(p[0],p[1]-1,p[2])};
var fmtDate=function(s){return parse(s).toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short'})};
var fmtLong=function(s){return parse(s).toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'})};
var fmtTime=function(t){var p=t.split(':').map(Number),h=p[0],ap=h>=12?'PM':'AM';h=h%12||12;return h+':'+pad(p[1])+' '+ap};
var toMin=function(t){var p=t.split(':').map(Number);return p[0]*60+p[1]};
var inr=function(n){return '₹'+Number(n).toLocaleString('en-IN')};
function wd(n){var d=new Date();d.setDate(d.getDate()+n);if(d.getDay()===0)d.setDate(d.getDate()+(n>=0?1:-1));return iso(d)}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,5)}
