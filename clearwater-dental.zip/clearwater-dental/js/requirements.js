'use strict';
/* Requirements tracker for the dashboard */
/* requirements tracker */
var REQ=[
['Website Pages','Home Page','Must-have',1,'B','Hero, services, reviews and booking call to action.'],
['Website Pages','About Us','Must-have',1,'B','History, mission, facilities and a timeline.'],
['Website Pages','Services','Must-have',1,'B','Eight treatments, each with its own detail page.'],
['Website Pages','Dentist Profiles','Must-have',1,'B','Placeholder portraits. Add real photos before launch.'],
['Website Pages','Appointment Booking','Must-have',1,'B','Live slot availability from dentist working hours.'],
['Website Pages','Contact Us','Must-have',1,'B','Phone, email, address, hours and map.'],
['Website Pages','Testimonials','Recommended',1,'B','Sample reviews. Use consented patient feedback.'],
['Website Pages','FAQs','Recommended',1,'B','Editable from the Content tab.'],
['Website Pages','Blog','Optional',2,'B','Three sample articles, editable.'],
['Website Pages','Privacy Policy','Must-have',1,'B','Draft text. Needs legal review.'],
['Core Features','Responsive Design','Must-have',1,'B','Tested layouts down to phone width.'],
['Core Features','Appointment Form','Must-have',1,'B','Contact details, treatment, dentist and time.'],
['Core Features','Form Validation','Must-have',1,'B','Inline errors for every required field and format.'],
['Core Features','WhatsApp Integration','Must-have',1,'B','Chat links with prefilled messages.'],
['Core Features','Click-to-Call','Must-have',1,'B','Tap-to-call links with a copy-number fallback.'],
['Core Features','Google Maps','Must-have',1,'S','Illustrative map with links to Google Maps. Embed on the live site.'],
['Core Features','Appointment Notifications','Recommended',2,'S','Message previews and a log. No real messages are sent.'],
['Core Features','Spam Protection','Must-have',1,'B','Hidden field, timing check, quick question and rate limit. Add server checks at launch.'],
['Admin Dashboard','Secure Admin Login','Must-have',2,'S','Demo login with lockout. Use real accounts at launch.'],
['Admin Dashboard','Appointment Management','Must-have',2,'B','Confirm, reschedule, cancel and remind.'],
['Admin Dashboard','Appointment Status','Must-have',2,'B','Pending, Confirmed, Completed, Cancelled, No-show.'],
['Admin Dashboard','Dentist Management','Recommended',2,'B','Profiles and working hours.'],
['Admin Dashboard','Service Management','Recommended',2,'B','Add, edit and remove treatments.'],
['Admin Dashboard','Content Management','Optional',2,'B','FAQs, testimonials and blog posts.'],
['Admin Dashboard','Dashboard Overview','Recommended',2,'B','Today and upcoming appointments.'],
['Technical','Frontend','Must-have',1,'B','Plain HTML, CSS and JavaScript. Move to Next.js if the project grows.'],
['Technical','Backend','As needed',2,'P','Needed to store bookings and send messages.'],
['Technical','Database','As needed',2,'P','Bookings are stored in this browser only. Use PostgreSQL or Supabase.'],
['Technical','Hosting','Must-have',1,'P','Deploy the site and backend.'],
['Technical','Image Storage','Recommended',2,'P','Store dentist and clinic photos securely.'],
['Technical','Backups','Must-have',2,'P','Schedule regular database backups.'],
['Security','HTTPS','Must-have',1,'P','Enabled by the host at launch.'],
['Security','Access Control','Must-have',2,'S','Dashboard is gated here. Enforce roles on the server.'],
['Security','Data Privacy','Must-have',1,'B','The form collects only what is needed.'],
['Security','Secure Notifications','Must-have',2,'B','Messages never include health details.'],
['SEO & Marketing','Page Metadata','Must-have',1,'B','Title and description change with each page.'],
['SEO & Marketing','Local SEO','Must-have',1,'B','Location in service pages and structured data.'],
['SEO & Marketing','Google Business Profile','Recommended',3,'P','Keep contact details identical to the site.'],
['SEO & Marketing','Performance','Must-have',1,'B','No heavy images. Optimise photos when added.'],
['SEO & Marketing','Analytics','Recommended',3,'S','Cookie-free counters here. Use a privacy-friendly tool live.'],
['Testing & Launch','Mobile Testing','Must-have',1,'P','Test on real phones before launch.'],
['Testing & Launch','Form Testing','Must-have',1,'P','Test submission end to end with the backend.'],
['Testing & Launch','Accessibility','Must-have',1,'P','Skip link, labels and focus styles included. Run a full audit.'],
['Testing & Launch','Security Review','Must-have',2,'P','Review authentication, access and data handling.'],
['Testing & Launch','Deployment','Must-have',1,'P','Publish and verify the production site.'],
['Future Enhancements','Online Payments','Optional',3,'F','Deposits at booking time.'],
['Future Enhancements','Patient Portal','Advanced',3,'F','Secure records and treatment plans.'],
['Future Enhancements','Automated Reminders','Optional',3,'F','Email, SMS or WhatsApp on a schedule.']
];
var SL={B:'Working in demo',S:'Simulated',P:'Production step',F:'Future'};
function tabReqs(){
  var cnt={B:0,S:0,P:0,F:0};REQ.forEach(function(r){cnt[r[4]]++});
  var cats=[];REQ.forEach(function(r){if(cats.indexOf(r[0])<0)cats.push(r[0])});
  return '<div class="tiles">'+['B','S','P','F'].map(function(k){return '<div class="tile"><b>'+cnt[k]+'</b>'+SL[k]+'</div>'}).join('')+'</div>'+
  '<div class="note" style="margin-bottom:1.5rem"><strong>Phase 1</strong> covers the public site, booking form, WhatsApp and contact. <strong>Phase 2</strong> adds the dashboard, booking management and notifications. <strong>Phase 3</strong> covers SEO growth, payments and advanced scheduling.</div>'+
  cats.map(function(c){return '<h3 style="margin:1.5rem 0 .6rem">'+c+'</h3><div class="tw"><table><thead><tr><th>Requirement</th><th>Priority</th><th>Phase</th><th>Status</th><th>Notes</th></tr></thead><tbody>'+REQ.filter(function(r){return r[0]===c}).map(function(r){return '<tr><td><strong>'+r[1]+'</strong></td><td>'+r[2]+'</td><td>'+r[3]+'</td><td><span class="chip s-'+r[4]+'">'+SL[r[4]]+'</span></td><td>'+r[5]+'</td></tr>'}).join('')+'</tbody></table></div>'}).join('');
}
