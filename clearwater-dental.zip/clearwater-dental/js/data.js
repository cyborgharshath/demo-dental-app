'use strict';
/* Sample data and browser storage */
/* ---------- seed data ---------- */
function seed(){
  var services=[
    {id:'checkup',name:'Check-up and cleaning',short:'A thorough exam, scale and polish, and a plan you understand.',price:600,dur:'30 to 45 min',desc:'A routine visit that catches small problems early. We examine your teeth, gums and bite, remove plaque and tartar, polish, and talk through what we found in plain language.',steps:['Medical and dental history review','Full mouth examination and X-rays only when needed','Scaling and polishing','Personal care advice and a recall date']},
    {id:'whitening',name:'Teeth whitening',short:'Professional whitening in a single visit, with a take-home top-up kit.',price:6000,dur:'60 min',desc:'Supervised in-clinic whitening that lifts everyday stains from coffee, tea and ageing. We check that your teeth and gums are healthy first, so the result is even and comfortable.',steps:['Shade check and gum protection','Whitening gel applied and activated in three short rounds','Sensitivity care and a top-up tray for home','Aftercare list for the first 48 hours']},
    {id:'filling',name:'Tooth-coloured fillings',short:'Repair cavities with fillings matched to your natural shade.',price:1200,dur:'45 min',desc:'Decayed or chipped teeth are repaired with a composite resin that blends with the tooth. We numb the area, remove the decay and shape the filling to fit your bite.',steps:['Numbing and comfort check','Decay removal','Layered composite filling, shaped and cured','Bite check and polish']},
    {id:'root-canal',name:'Root canal treatment',short:'Save a painful or infected tooth with a careful, well-numbed procedure.',price:4500,dur:'60 to 90 min',desc:'When the nerve of a tooth is inflamed or infected, a root canal removes the damaged tissue, cleans the canals and seals them. Most patients feel the relief within a day or two.',steps:['Diagnosis with a digital X-ray','Local anaesthetic and isolation of the tooth','Canal cleaning and shaping','Sealing, followed by a crown if advised']},
    {id:'braces',name:'Braces and clear aligners',short:'Straighter teeth with metal, ceramic or clear aligner options.',price:35000,dur:'Consultation 45 min',desc:'Our orthodontist reviews your bite and goals, explains each option with its timeline and cost, and plans treatment in stages. Adults and teenagers are both welcome.',steps:['Consultation, photos and impressions or scan','Treatment plan with a time estimate','Fitting of braces or first aligner set','Regular adjustment visits and retainers']},
    {id:'implants',name:'Dental implants',short:'A fixed replacement for a missing tooth that looks and feels natural.',price:28000,dur:'Planned over several visits',desc:'An implant is a small titanium post placed in the jaw that supports a crown. We plan each case with a scan, so you know the steps, the healing time and the full cost before we begin.',steps:['Scan and bone assessment','Implant placement under local anaesthetic','Healing period of a few months','Crown fitting and follow-up']},
    {id:'crown',name:'Crowns and bridges',short:'Strengthen a weak tooth or close a gap with a custom-made restoration.',price:5000,dur:'Two visits',desc:'A crown covers and protects a damaged tooth. A bridge replaces one or more missing teeth using neighbouring teeth for support. Both are made to match your shade and bite.',steps:['Tooth preparation and impression or scan','Temporary crown while the lab makes yours','Fitting and bite adjustment','Care advice for the long term']},
    {id:'kids',name:'Children’s dentistry',short:'Gentle first visits, sealants and fluoride care for young patients.',price:500,dur:'30 min',desc:'We keep visits short, friendly and unhurried. Our paediatric dentist introduces each step with simple words, and parents are welcome in the room.',steps:['Meet-and-greet and a look around','Gentle examination','Cleaning, fluoride or sealants as needed','Brushing coaching for child and parent']}
  ];
  var dentists=[
    {id:'ananya',name:'Dr. Ananya Raghavan',role:'Orthodontist',qual:'BDS, MDS (Orthodontics)',years:12,bio:'Ananya treats crowded and uneven teeth in teenagers and adults. She explains every option before recommending one.',days:[1,2,3,4,5],start:'09:00',end:'17:00',treats:['checkup','braces']},
    {id:'karthik',name:'Dr. Karthik Subramanian',role:'Endodontist and Implant Dentist',qual:'BDS, MDS (Endodontics), Implantology fellowship',years:15,bio:'Karthik handles root canals and implant planning. Patients often say they barely noticed the procedure.',days:[1,3,5,6],start:'10:00',end:'19:00',treats:['root-canal','implants','crown','filling']},
    {id:'meera',name:'Dr. Meera Iyer',role:'Paediatric Dentist',qual:'BDS, MDS (Paedodontics)',years:9,bio:'Meera makes first dental visits easy for children, and for the parents who worry about them.',days:[2,3,4,5,6],start:'09:00',end:'16:00',treats:['kids','checkup','filling']},
    {id:'rohan',name:'Dr. Rohan Das',role:'General and Cosmetic Dentist',qual:'BDS, Certificate in Aesthetic Dentistry',years:8,bio:'Rohan looks after day-to-day dental health and smile makeovers, from whitening to crowns.',days:[1,2,3,4,5,6],start:'11:00',end:'19:00',treats:['checkup','whitening','filling','crown']}
  ];
  var reviews=[
    {id:'r1',name:'Arjun M.',treat:'Root canal treatment',rating:5,text:'I came in with a toothache I had ignored for weeks. The procedure was calm and quick, and I was told exactly what to expect at each step.'},
    {id:'r2',name:'Divya N.',treat:'Teeth whitening',rating:5,text:'Booking took a minute, the reminder came the day before, and the result was natural. No sensitivity afterwards.'},
    {id:'r3',name:'Fatima K.',treat:'Braces consultation',rating:4,text:'Clear explanation of the options and the cost, with no pressure to decide that day. I appreciated the written plan.'},
    {id:'r4',name:'Priya N.',treat:'Children’s dentistry',rating:5,text:'My son used to cry at the word dentist. Dr. Meera let him hold the mirror first, and he asked to come back.'},
    {id:'r5',name:'Joseph D.',treat:'Dental implant',rating:5,text:'The scan and the step-by-step timeline made a big decision feel manageable. Every visit started on time.'}
  ];
  var faqs=[
    {id:'f1',q:'How often should I visit the dentist?',a:'Most adults do well with a check-up and cleaning every six months. If you have gum disease, braces or a history of cavities, we may suggest more frequent visits.'},
    {id:'f2',q:'Is treatment painful?',a:'We numb the area before any procedure that could be uncomfortable, and we check in with you throughout. Tell us at any point if you want a pause.'},
    {id:'f3',q:'Do I need to book in advance?',a:'Booking ahead is best, and you can request a time online in a minute. For dental pain we try to fit you in on the same day, so call or message us on WhatsApp.'},
    {id:'f4',q:'What should I bring to my first visit?',a:'Bring any previous dental records or X-rays you have, and a list of medicines you take. You do not need to prepare anything else.'},
    {id:'f5',q:'How do you keep instruments safe?',a:'Instruments are cleaned, packed and sterilised in an autoclave after every patient. Single-use items are opened in front of you and discarded afterwards.'},
    {id:'f6',q:'Can I change or cancel my appointment?',a:'Yes. Reply to your confirmation message or call us, ideally a day ahead, so we can offer the slot to someone else.'}
  ];
  var posts=[
    {id:'p1',title:'How often should you really get a dental check-up?',date:wd(-9),cat:'Prevention',excerpt:'Six months is a good default, but your own mouth should set the schedule.',body:['The six-month rule is a sensible starting point for most adults. It gives us enough time to spot a small cavity or early gum inflammation before it becomes painful or expensive.','Some people need to come in more often. If you wear braces, smoke, have diabetes, or have had gum disease before, three to four months can keep problems from returning.','If you have had no problems for several years, your dentist may suggest a longer gap. The right answer comes from an examination, not from a calendar.']},
    {id:'p2',title:'Whitening: what works and what to skip',date:wd(-21),cat:'Cosmetic',excerpt:'A short guide to professional whitening and the home tricks that do more harm than good.',body:['Professional whitening uses a controlled gel concentration and protects your gums. It is the quickest way to lift stains from tea, coffee and age, and the results usually last a year or more with good habits.','Skip charcoal powders and lemon juice. They wear down enamel, which makes teeth look yellower over time and more sensitive.','Whitening does not change the colour of fillings or crowns. Tell us about any you have, so we can plan the shade you are aiming for.']},
    {id:'p3',title:'Helping children feel calm at the dentist',date:wd(-34),cat:'Families',excerpt:'Small things parents can do before the first visit make a big difference.',body:['Keep the language simple and positive. Say the dentist will count and clean the teeth, and avoid words like pain or needle.','Book the first visit before there is a problem. A short, friendly appointment builds trust, so later treatment feels familiar.','Stay with your child and let the dentist lead the conversation. Children read your face, so a relaxed parent is the best tool in the room.']}
  ];
  var rows=[
    ['Arjun Menon','90000 10001','root-canal','karthik',0,'10:00','Confirmed'],
    ['Divya Nair','90000 10002','checkup','rohan',0,'11:30','Pending'],
    ['Sanjay Patel','90000 10003','filling','ananya',0,'09:30','Completed'],
    ['Fatima Khan','90000 10004','whitening','rohan',0,'15:00','Confirmed'],
    ['Lakshmi Venkat','90000 10005','braces','ananya',1,'10:30','Pending'],
    ['Joseph D’Souza','90000 10006','implants','karthik',1,'14:00','Confirmed'],
    ['Priya Natarajan','90000 10007','kids','meera',2,'10:00','Pending'],
    ['Imran Sheikh','90000 10008','crown','any',3,'16:00','Confirmed'],
    ['Kavya Reddy','90000 10009','checkup','meera',-1,'12:00','No-show'],
    ['Nikhil Joshi','90000 10010','filling','rohan',-2,'17:00','Cancelled']
  ];
  var appts=rows.map(function(r,i){return {id:'a'+i,ref:'CWD-'+(1001+i),name:r[0],phone:r[1],email:'',service:r[2],dentist:r[3],date:wd(r[4]),time:r[5],status:r[6],note:'',created:Date.now()}});
  return {v:1,seq:1011,services:services,dentists:dentists,reviews:reviews,faqs:faqs,posts:posts,appts:appts,notes:[],stats:{views:{},bookView:0,bookings:0}};
}
var S=null,memOnly=null;
function load(){try{var r=localStorage.getItem(KEY);if(r){var d=JSON.parse(r);if(d&&d.v===1)return d}}catch(e){}return null}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){memOnly=S}}
S=load()||seed();
