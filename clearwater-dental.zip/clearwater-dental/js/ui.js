'use strict';
/* Interface state, page titles, header and footer */
/* ---------- UI state ---------- */
var route='home',ui={menu:false,tab:'overview',f:'All',q:'',resch:null,open:'',del:'',auth:false,fails:0,lockUntil:0,submits:[],chal:null,bookStart:0,preService:'',done:null};
var head=$('#head'),main=$('#main'),foot=$('#foot');
function toast(m){var t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(function(){t.hidden=true},3200)}
function copy(text){
  var ok=function(){toast('Copied: '+text)};
  var fail=function(){toast('Select the text to copy it: '+text)};
  try{navigator.clipboard.writeText(text).then(ok,fail)}catch(e){fail()}
}
var waLink=function(msg){return 'https://wa.me/'+C.wa+'?text='+encodeURIComponent(msg||'Hello Clearwater Dental, I would like to ask about an appointment.')};
var mapsLink='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(C.name+', '+C.addr);
var lk=function(r,txt,cls){return '<a href="#'+r.replace(':','-')+'" data-go="'+r+'"'+(cls?' class="'+cls+'"':'')+'>'+txt+'</a>'};
var tooth='<svg viewBox="0 0 64 76" aria-hidden="true"><path d="M32 6c-6 0-10 2-14 2C11 8 7 13 7 21c0 8 4 13 5 21 1 9 2 28 8 28 4 0 4-15 6-22 1-4 5-4 6 0 2 7 2 22 6 22 6 0 7-19 8-28 1-8 5-13 5-21 0-8-4-13-11-13-4 0-8-2-14-2z" fill="#ffffff" stroke="#2f8bd6" stroke-width="3" stroke-linejoin="round"/><path d="M20 20c2-3 5-4 8-4" fill="none" stroke="#b9dcf5" stroke-width="3" stroke-linecap="round"/></svg>';

/* ---------- meta ---------- */
var PAGES={home:['Clearwater Dental | Gentle family and cosmetic dentistry','Gentle family and cosmetic dentistry. Meet our dentists, explore treatments and request an appointment online.'],
about:['About Clearwater Dental | Our clinic and values','Learn about our clinic, our approach to care, our facilities and our experience.'],
services:['Dental treatments | Clearwater Dental','Check-ups, whitening, fillings, root canals, braces, implants, crowns and children’s dentistry in Greenfield.'],
dentists:['Our dentists | Clearwater Dental','Meet our dentists, their qualifications, specialties and working days.'],
book:['Book an appointment | Clearwater Dental','Request a dental appointment online. Choose your treatment, dentist and a time that suits you.'],
contact:['Contact and directions | Clearwater Dental','Call, WhatsApp or visit us. Opening hours, address and directions.'],
reviews:['Patient reviews | Clearwater Dental','Feedback from patients about their care at Clearwater Dental.'],
faqs:['Dental FAQs | Clearwater Dental','Answers to common questions about visits, comfort, safety and booking.'],
blog:['Dental health blog | Clearwater Dental','Practical articles on caring for your teeth and gums.'],
privacy:['Privacy policy | Clearwater Dental','How we collect, use and protect your personal data.'],
admin:['Staff dashboard | Clearwater Dental','Staff area for managing appointments and clinic content.']};
function setMeta(name,arg){
  var p=PAGES[name]||PAGES.home,t=p[0],d=p[1];
  if(name==='service'){var s=svc(arg);if(s){t=s.name+' in Greenfield | Clearwater Dental';d=s.short+' Book a visit at Clearwater Dental, Greenfield.'}}
  if(name==='post'){var po=S.posts.find(function(x){return x.id===arg});if(po){t=po.title+' | Clearwater Dental';d=po.excerpt}}
  document.title=t;
  var m=document.querySelector('meta[name="description"]');if(m)m.setAttribute('content',d);
}

/* ---------- chrome ---------- */
var NAV=[['home','Home'],['about','About us'],['book','Book appointment'],['contact','Contact']];
function headerHTML(name){
  var cur=name==='service'?'services':name==='post'?'blog':name;
  var open=openNow();
  return '<div class="strip"><div class="wrap"><span><span class="open-dot'+(open?'':' closed')+'"></span>'+(open?'Open now until 7 PM':'Closed now. Mon to Sat, 9 AM to 7 PM')+'</span><span>Call <a href="tel:'+C.tel+'">'+C.phone+'</a></span></div></div>'+
  '<header class="site"><div class="wrap bar">'+
  '<a class="logo" href="#home" data-go="home" aria-label="Clearwater Dental home">'+tooth+'<span>Clearwater Dental</span></a>'+
  '<nav class="main'+(ui.menu?' open':'')+'" id="nav" aria-label="Main"><ul>'+NAV.map(function(n){return '<li>'+lk(n[0],n[1]).replace('<a ','<a '+(cur===n[0]?'aria-current="page" ':''))+'</li>'}).join('')+'</ul></nav>'+
  '</div></header>';
}
function footerHTML(){
  return '<footer class="site"><div class="wrap"><div class="foot-grid">'+
  '<div><a class="logo" href="#home" data-go="home">'+tooth+'<span>Clearwater Dental</span></a><p class="small" style="margin-top:.7rem">Gentle family and cosmetic dentistry.</p><p class="small" style="margin-top:.7rem">This is a demo site. Names, prices, reviews and contact details are sample content.</p></div>'+
  '<div><h4>Visit</h4><ul><li>'+esc(C.addr)+'</li>'+HOURS.map(function(h){return '<li><span class="small">'+h[0]+':</span> '+h[1]+'</li>'}).join('')+'</ul></div>'+
  '<div><h4>Contact</h4><ul><li><a href="tel:'+C.tel+'">'+C.phone+'</a></li><li><a href="mailto:'+C.email+'">'+C.email+'</a></li><li><a href="'+waLink()+'" target="_blank" rel="noopener">Message on WhatsApp</a></li></ul></div>'+
  '<div><h4>Explore</h4><ul><li>'+lk('services','Treatments')+'</li><li>'+lk('book','Book online')+'</li><li>'+lk('privacy','Privacy policy')+'</li><li>'+lk('admin','Staff login')+'</li></ul></div>'+
  '</div></div></footer>';
}
