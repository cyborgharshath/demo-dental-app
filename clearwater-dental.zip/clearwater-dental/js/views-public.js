'use strict';
/* Home, About us and Contact pages */
/* ---------- public views ---------- */
function serviceCard(s){return '<a class="card link" href="#service-'+s.id+'" data-go="service:'+s.id+'"><h3>'+esc(s.name)+'</h3><p>'+esc(s.short)+'</p><p class="meta">From '+inr(s.price)+' · '+esc(s.dur)+'</p></a>'}
function stars(n){return '<span class="stars" role="img" aria-label="'+n+' out of 5 stars">'+'★'.repeat(n)+'☆'.repeat(5-n)+'</span>'}
function reviewCard(r){return '<div class="card"><blockquote>'+stars(r.rating)+'<p style="margin-top:.4rem">'+esc(r.text)+'</p></blockquote><p class="meta"><strong>'+esc(r.name)+'</strong> · '+esc(r.treat)+'</p></div>'}
function avatar(d,i){var ini=d.name.replace('Dr. ','').split(' ').map(function(w){return w[0]}).slice(0,2).join('');return '<div class="avatar av'+(i%4)+'" role="img" aria-label="Placeholder portrait of '+esc(d.name)+'">'+esc(ini)+'</div>'}
function dentistCard(d,i){return '<div class="card"><div class="dr">'+avatar(d,i)+'<div><h3>'+esc(d.name)+'</h3><p class="meta">'+esc(d.role)+'</p><p class="meta">'+esc(d.qual)+' · '+d.years+' years</p></div></div><p>'+esc(d.bio)+'</p><p class="small">'+esc(daysText(d))+'</p></div>'}
function pageHead(title,sub,crumbs){return '<div class="page-head"><div class="wrap">'+(crumbs||'')+'<h1 style="font-size:clamp(1.9rem,4.4vw,2.9rem)">'+title+'</h1>'+(sub?'<p class="lead">'+sub+'</p>':'')+'</div></div>'}
function ctaBand(){return '<section class="band"><div class="wrap"><div class="cta-band"><div><h2>Ready when you are.</h2><p>Request a time online. We confirm within working hours.</p></div><a class="btn" href="#book" data-go="book">Book an appointment</a></div></div></section>'}

var V={};
V.homeOld=function(){
  var ns=nextSlot();
  return '<section class="hero"><div class="wrap hero-grid"><div>'+
  '<p class="eyebrow">Family and cosmetic dentistry</p><h1>Gentle dental care, booked in a minute.</h1>'+
  '<p class="lead">Check-ups, whitening, root canals, braces and implants, explained in plain language and priced before we begin.</p>'+
  '<div class="row"><a class="btn" href="#book" data-go="book">Book an appointment</a><a class="btn wa" href="'+waLink()+'" target="_blank" rel="noopener">WhatsApp us</a></div>'+
  (ns?'<p class="small" style="margin-top:1rem">Next free slot: <strong>'+fmtDate(ns.date)+', '+fmtTime(ns.time)+'</strong></p>':'')+
  '</div><div class="art"><div class="disc"></div><div class="disc2"></div><svg class="tooth" viewBox="0 0 64 76" role="img" aria-label="Illustration of a healthy tooth"><path d="M32 6c-6 0-10 2-14 2C11 8 7 13 7 21c0 8 4 13 5 21 1 9 2 28 8 28 4 0 4-15 6-22 1-4 5-4 6 0 2 7 2 22 6 22 6 0 7-19 8-28 1-8 5-13 5-21 0-8-4-13-11-13-4 0-8-2-14-2z" fill="#e3f1fc" stroke="#2f8bd6" stroke-width="2.5" stroke-linejoin="round"/><path d="M20 20c2-3 5-4 8-4" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>'+
  '<div class="float f1"><strong>'+onDutyToday()+' dentists on duty</strong>today</div>'+
  (ns?'<div class="float f2"><strong>'+fmtTime(ns.time)+'</strong>'+fmtDate(ns.date)+' is open</div>':'')+
  '</div></div></section>'+
  '<section class="band" style="padding-top:0"><div class="wrap"><div class="facts"><div><b>Mon to Sat</b>9 AM to 7 PM</div><div><b>'+S.dentists.length+' dentists</b>across 4 specialties</div><div><b>Same-day care</b>for dental pain</div><div><b>Sterilised</b>instruments, every patient</div></div></div></section>'+
  '<section class="band tint"><div class="wrap"><div class="sec-head"><p class="eyebrow">Treatments</p><h2>Care for every stage of your smile</h2></div><div class="grid g4">'+S.services.slice(0,8).map(serviceCard).join('')+'</div><p style="margin-top:1.2rem">'+lk('services','See all treatments and prices')+'</p></div></section>'+
  '<section class="band"><div class="wrap"><div class="sec-head"><p class="eyebrow">How booking works</p><h2>Three steps, no phone queue</h2></div><ol class="steps" style="max-width:60ch"><li><div><h3>Pick a treatment and time</h3><p class="muted">Only open slots are shown, based on each dentist’s working hours.</p></div></li><li><div><h3>We confirm your request</h3><p>Our team confirms by WhatsApp or phone during working hours.</p></div></li><li><div><h3>Get a reminder, then visit</h3><p>You hear from us the day before. Reply to change the time.</p></div></li></ol></div></section>'+
  '<section class="band tint"><div class="wrap"><div class="sec-head"><p class="eyebrow">Our dentists</p><h2>Specialists you can talk to</h2></div><div class="grid g4">'+S.dentists.map(dentistCard).join('')+'</div></div></section>'+
  '<section class="band"><div class="wrap"><div class="sec-head"><p class="eyebrow">Patient feedback</p><h2>What patients say</h2><p class="small">Sample reviews for this demo. Replace them with feedback patients have agreed to share.</p></div><div class="grid g3">'+S.reviews.slice(0,3).map(reviewCard).join('')+'</div><p style="margin-top:1.2rem">'+lk('reviews','Read more reviews')+'</p></div></section>'+
  ctaBand();
};
V.about=function(){
  var yrs=S.dentists.reduce(function(a,d){return a+d.years},0);
  return pageHead('About Clearwater Dental','A neighbourhood clinic built around clear explanations and unhurried visits.')+
  '<section class="band"><div class="wrap grid g2" style="gap:2.5rem"><div class="prose"><h2>Our mission</h2><p>We want every patient to leave knowing what was done, why it was needed and what comes next. We quote costs before treatment, and we never rush a decision.</p><p>Clearwater Dental opened in 2011 as a two-chair practice. It has grown into a team of '+S.dentists.length+' dentists, each focused on the work they do best.</p><h2>Facilities</h2><ul><li>Three treatment rooms, including a calm room for children</li><li>Digital X-ray with low radiation dose</li><li>Autoclave sterilisation, with single-use items opened in front of you</li><li>Step-free entrance and an accessible restroom</li><li>Waiting area with water and charging points</li></ul></div>'+
  '<div class="stack"><div class="facts" style="grid-template-columns:1fr 1fr"><div><b>'+yrs+'+ years</b>combined experience</div><div><b>'+S.services.length+'</b>treatments offered</div></div><h2 style="font-size:1.4rem">Our story</h2><ol class="timeline"><li><b>2011</b><p>Opens as a two-chair clinic offering general dentistry.</p></li><li><b>2015</b><p>Adds orthodontics and a dedicated children’s room.</p></li><li><b>2019</b><p>Opens an implant suite with 3D scanning.</p></li><li><b>2024</b><p>Introduces online booking and WhatsApp reminders.</p></li></ol></div></div></section>'+ctaBand();
};
V.services=function(){
  return pageHead('Treatments and prices','Prices are indicative starting points. You receive a written estimate before any treatment.')+
  '<section class="band"><div class="wrap"><div class="grid g3">'+S.services.map(serviceCard).join('')+'</div></div></section>'+ctaBand();
};
V.service=function(id){
  var s=svc(id);if(!s)return V.services();
  var who=S.dentists.filter(function(d){return d.treats.indexOf(s.id)>-1});
  var others=S.services.filter(function(x){return x.id!==s.id}).slice(0,3);
  return pageHead(esc(s.name)+' in Greenfield',esc(s.short),'<p class="crumbs">'+lk('services','Treatments')+' / '+esc(s.name)+'</p>')+
  '<section class="band"><div class="wrap book-grid"><div class="prose"><p>'+esc(s.desc)+'</p><h2>What to expect</h2><ol class="steps">'+s.steps.map(function(x){return '<li><div>'+esc(x)+'</div></li>'}).join('')+'</ol><h2>Who treats this</h2><div class="grid g2">'+(who.length?who.map(function(d){return dentistCard(d,S.dentists.indexOf(d))}).join(''):'<p class="small">Ask us who is best placed to help.</p>')+'</div></div>'+
  '<aside class="card"><h3>At a glance</h3><p><span class="small">Indicative price</span><br><strong style="font-size:1.4rem;color:var(--blue-deep)">From '+inr(s.price)+'</strong></p><p><span class="small">Typical time</span><br><strong>'+esc(s.dur)+'</strong></p><a class="btn" href="#book" data-go="book" data-svc="'+s.id+'">Book this treatment</a><a class="btn wa" href="'+waLink('Hello Clearwater Dental, I would like to ask about '+s.name+'.')+'" target="_blank" rel="noopener">Ask on WhatsApp</a></aside></div></section>'+
  '<section class="band tint"><div class="wrap"><h2 style="margin-bottom:1.2rem">Other treatments</h2><div class="grid g3">'+others.map(serviceCard).join('')+'</div></div></section>';
};
V.dentists=function(){
  return pageHead('Our dentists','Qualified specialists with a shared habit of explaining things clearly.')+
  '<section class="band"><div class="wrap"><div class="grid g2">'+S.dentists.map(dentistCard).join('')+'</div><p class="small" style="margin-top:1rem">Portraits are placeholders. Swap in real photographs, with each dentist’s consent, before launch.</p></div></section>'+ctaBand();
};
V.reviews=function(){
  var avg=S.reviews.length?(S.reviews.reduce(function(a,r){return a+Number(r.rating)},0)/S.reviews.length).toFixed(1):'0.0';
  return pageHead('Patient reviews',S.reviews.length+' sample reviews, average '+avg+' out of 5.')+
  '<section class="band"><div class="wrap"><div class="note" style="margin-bottom:1.5rem">These reviews are sample content for the demo. On the live site, publish only feedback that patients have agreed to share.</div><div class="grid g3">'+S.reviews.map(reviewCard).join('')+'</div></div></section>'+ctaBand();
};
V.faqs=function(){
  return pageHead('Frequently asked questions','Quick answers about visits, comfort, safety and booking.')+
  '<section class="band"><div class="wrap" style="max-width:820px">'+S.faqs.map(function(f){return '<details class="q"><summary>'+esc(f.q)+'</summary><p>'+esc(f.a)+'</p></details>'}).join('')+'<p style="margin-top:1.5rem">Still unsure? '+lk('contact','Talk to our team')+'.</p></div></section>';
};
V.blog=function(){
  return pageHead('Dental health blog','Practical advice from our dentists.')+
  '<section class="band"><div class="wrap"><div class="grid g3">'+S.posts.map(function(p){return '<a class="card link" href="#post-'+p.id+'" data-go="post:'+p.id+'"><span class="tag">'+esc(p.cat)+'</span><h3>'+esc(p.title)+'</h3><p>'+esc(p.excerpt)+'</p><p class="meta">'+fmtLong(p.date)+'</p></a>'}).join('')+'</div></div></section>';
};
V.post=function(id){
  var p=S.posts.find(function(x){return x.id===id});if(!p)return V.blog();
  return pageHead(esc(p.title),'', '<p class="crumbs">'+lk('blog','Blog')+' / '+esc(p.cat)+' · '+fmtLong(p.date)+'</p>')+
  '<section class="band"><div class="wrap"><div class="prose">'+p.body.map(function(x){return '<p>'+esc(x)+'</p>'}).join('')+'<p class="note">General information only. It does not replace a dental examination.</p><p>'+lk('blog','Back to all articles')+'</p></div></div></section>'+ctaBand();
};
V.privacy=function(){
  return pageHead('Privacy policy','Draft text for the demo. Have it reviewed against local law before launch.')+
  '<section class="band"><div class="wrap"><div class="prose">'+
  '<h2>What we collect</h2><p>When you request an appointment we collect your name, phone number, preferred treatment, date and time. Email and a short note are optional. Please do not put medical details in the note.</p>'+
  '<h2>Why we collect it</h2><p>We use your details to arrange, confirm and remind you about your appointment, and to contact you if the time needs to change. We do not sell your data or use it for third-party advertising.</p>'+
  '<h2>Messages we send</h2><p>Confirmations and reminders include your first name, date, time and booking reference. They never mention your diagnosis or treatment details.</p>'+
  '<h2>Analytics</h2><p>We count page visits and booking requests without cookies or personal identifiers, so we can improve the site.</p>'+
  '<h2>How long we keep it</h2><p>Appointment requests are kept for as long as needed to provide care and meet record-keeping rules, then deleted.</p>'+
  '<h2>Your choices</h2><p>You can ask us to see, correct or delete the details we hold about you. Contact us at <a href="mailto:'+C.email+'">'+C.email+'</a> or call '+C.phone+'.</p>'+
  '<h2>Security</h2><p>The site uses HTTPS, staff access is limited to authorised users, and we collect only what we need.</p></div></div></section>';
};
function mapSVG(){
  return '<svg class="map" viewBox="0 0 600 340" role="img" aria-label="Simple map showing the clinic on Lake View Road"><rect width="600" height="340" fill="#f3f9fe"/><path d="M0 240c120-20 180 30 300 10s200-70 300-40v130H0z" fill="#d6ebfb"/><g stroke="#fff" stroke-width="14" fill="none" stroke-linecap="round"><path d="M0 120H600"/><path d="M180 0V340"/><path d="M420 0V340"/><path d="M0 60L600 190"/></g><g stroke="#cfe2f2" stroke-width="2" fill="none"><path d="M0 120H600"/><path d="M180 0V340"/><path d="M420 0V340"/><path d="M0 60L600 190"/></g><text x="30" y="108" font-size="13" fill="#516579" font-family="Figtree,sans-serif">Lake View Road</text><text x="190" y="30" font-size="13" fill="#516579" font-family="Figtree,sans-serif">Market Street</text><text x="440" y="30" font-size="13" fill="#516579" font-family="Figtree,sans-serif">Station Road</text><g transform="translate(300 118)"><path d="M0 0c-14-18-24-28-24-42a24 24 0 0 1 48 0c0 14-10 24-24 42z" fill="#1d6cb3"/><circle cx="0" cy="-42" r="9" fill="#fff"/></g><text x="300" y="150" text-anchor="middle" font-size="14" font-weight="700" fill="#124a7c" font-family="Figtree,sans-serif">Clearwater Dental</text></svg>';
}
V.contact=function(){
  return pageHead('Contact and directions','Call, message us on WhatsApp, or walk in during opening hours.')+
  '<section class="band"><div class="wrap book-grid"><div class="stack">'+mapSVG()+'<p class="small">Illustrative map. The live site embeds Google Maps.</p><div class="row"><a class="btn" href="'+mapsLink+'" target="_blank" rel="noopener">Open in Google Maps</a><a class="btn ghost" href="https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(C.name+', '+C.addr)+'" target="_blank" rel="noopener">Get directions</a></div></div>'+
  '<div class="stack"><div class="card"><h3>Phone</h3><p><a href="tel:'+C.tel+'" style="font-size:1.3rem;font-weight:700">'+C.phone+'</a></p><div class="row"><a class="btn sm" href="tel:'+C.tel+'">Call now</a><button class="btn sm ghost" type="button" data-act="copy" data-text="'+C.phone+'">Copy number</button></div></div>'+
  '<div class="card"><h3>WhatsApp</h3><p class="small">Fastest for changing a booking or asking a quick question.</p><a class="btn wa sm" href="'+waLink()+'" target="_blank" rel="noopener">Start a chat</a></div>'+
  '<div class="card"><h3>Email</h3><p><a href="mailto:'+C.email+'">'+C.email+'</a></p><button class="btn sm ghost" type="button" data-act="copy" data-text="'+C.email+'">Copy address</button></div>'+
  '<div class="card"><h3>Address</h3><p>'+esc(C.addr)+'</p></div>'+
  '<div class="card"><h3>Opening hours</h3><table><tbody>'+HOURS.map(function(h){return '<tr><td>'+h[0]+'</td><td>'+h[1]+'</td></tr>'}).join('')+'</tbody></table><p class="small">For dental pain outside these hours, message us on WhatsApp and we will reply when we open.</p></div></div></div></section>';
};

/* ---------- three pages: Home, Book, Staff ---------- */
var PAGEOF={services:'home',service:'home',blog:'home',post:'home',reviews:'home',dentists:'about',faqs:'about',privacy:'contact'},SECID={service:'services',post:'blog'};
function seeMore(next,title,sub){return '<section class="band seemore"><div class="wrap"><p class="eyebrow">Next</p><h2>'+title+'</h2><p class="lead">'+sub+'</p><a class="btn" href="#'+next+'" data-go="'+next+'">See more <span aria-hidden="true">→</span></a></div></section>'}
function bodyOf(h){return h.slice(h.indexOf('<section')).replace(ctaBand(),'')}
function secHead(id,eyebrow,title,sub){return '<section class="band sechead" id="'+id+'"><div class="wrap"><div class="sec-head" style="margin-bottom:0"><p class="eyebrow">'+eyebrow+'</p><h2>'+title+'</h2>'+(sub?'<p class="lead">'+sub+'</p>':'')+'</div></div></section>'}
function svcDetail(s){
  var who=S.dentists.filter(function(d){return d.treats.indexOf(s.id)>-1}).map(function(d){return d.name}).join(', ');
  return '<details class="card svc"><summary><h3>'+esc(s.name)+'</h3><p>'+esc(s.short)+'</p><p class="meta">From '+inr(s.price)+' · '+esc(s.dur)+' · <span class="more-hint">Details</span></p></summary><div class="more"><p>'+esc(s.desc)+'</p><div><h4>What to expect</h4><ol>'+s.steps.map(function(x){return '<li>'+esc(x)+'</li>'}).join('')+'</ol></div>'+(who?'<p class="small">Treated by '+esc(who)+'.</p>':'')+'<div class="row"><a class="btn sm" href="#book" data-go="book" data-svc="'+s.id+'">Book this treatment</a><a class="btn wa sm" href="'+waLink('Hello Clearwater Dental, I would like to ask about '+s.name+'.')+'" target="_blank" rel="noopener">Ask on WhatsApp</a></div></div></details>';
}
function postDetail(p){
  return '<details class="card svc"><summary><span class="tag" style="justify-self:start">'+esc(p.cat)+'</span><h3>'+esc(p.title)+'</h3><p>'+esc(p.excerpt)+'</p><p class="meta">'+fmtLong(p.date)+' · <span class="more-hint">Read article</span></p></summary><div class="more">'+p.body.map(function(x){return '<p>'+esc(x)+'</p>'}).join('')+'<p class="small">General information only. It does not replace a dental examination.</p></div></details>';
}
V.home=function(){
  var h=V.homeOld();
  var top=h.slice(0,h.indexOf('<section class="band tint">'));
  var a=h.indexOf('<section class="band"><div class="wrap"><div class="sec-head"><p class="eyebrow">How booking works'),b=h.indexOf('<section class="band tint">',a);
  var how=h.slice(a,b);
  return top+
  '<div class="tintwrap">'+secHead('services','Treatments','Treatments in Greenfield','Tap a treatment for what to expect, typical time and an indicative price.')+'<section class="band"><div class="wrap"><div class="grid g3 top">'+S.services.map(svcDetail).join('')+'</div></div></section></div>'+
  how+
  '<div class="tintwrap">'+secHead('reviews','Patient reviews','What patients say','')+bodyOf(V.reviews())+'</div>'+
  secHead('blog','Blog','Dental health blog','Practical advice from our dentists.')+'<section class="band"><div class="wrap"><div class="grid g3 top">'+S.posts.map(postDetail).join('')+'</div></div></section>'+
  seeMore('about','About us','Our story, our dentists and answers to common questions.');
};
var aboutOld=V.about,contactOld=V.contact;
V.about=function(){
  return aboutOld().replace(ctaBand(),'')+
  '<div class="tintwrap">'+secHead('dentists','Dentists','Meet our dentists','Qualified specialists with a shared habit of explaining things clearly.')+bodyOf(V.dentists())+'</div>'+
  secHead('faqs','FAQs','Frequently asked questions','Quick answers about visits, comfort, safety and booking.')+bodyOf(V.faqs())+
  seeMore('book','Book an appointment','Pick a treatment and a time that suits you.');
};
V.contact=function(){
  return contactOld()+'<div class="tintwrap"><section class="band" id="privacy"><div class="wrap"><details class="q"><summary>Privacy policy</summary>'+bodyOf(V.privacy()).replace(/^<section class="band"><div class="wrap">/,'').replace(/<\/div><\/section>$/,'')+'</details></div></section></div>';
};
