'use strict';
/* Appointment slots, lookups and patient message text */
/* ---------- data helpers ---------- */
var svc=function(id){return S.services.find(function(x){return x.id===id})};
var dn=function(id){if(id==='any')return 'First available dentist';var d=S.dentists.find(function(x){return x.id===id});return d?d.name:'Dentist'};
var sn=function(id){var s=svc(id);return s?s.name:'Treatment'};
var daysText=function(d){var a=DAYORDER.filter(function(x){return d.days.indexOf(x)>-1}).map(function(x){return DAYN[x]});return a.join(', ')+' · '+fmtTime(d.start)+' to '+fmtTime(d.end)};
function working(d,dow,t){return d.days.indexOf(dow)>-1&&toMin(d.start)<=toMin(t)&&toMin(t)+30<=toMin(d.end)}
function slotsFor(date,did,ignoreId){
  var d=parse(date),dow=d.getDay();
  if(dow===0)return [];
  var ds=S.dentists.filter(function(x){return (did==='any'||x.id===did)&&x.days.indexOf(dow)>-1});
  var times={};
  ds.forEach(function(x){for(var m=toMin(x.start);m+30<=toMin(x.end);m+=30){times[pad(Math.floor(m/60))+':'+pad(m%60)]=1}});
  var now=new Date(),isToday=date===today();
  return Object.keys(times).sort().filter(function(t){
    if(isToday&&toMin(t)<now.getHours()*60+now.getMinutes()+60)return false;
    var booked=S.appts.filter(function(a){return a.date===date&&a.time===t&&(a.status==='Pending'||a.status==='Confirmed')&&a.id!==ignoreId});
    var open=ds.filter(function(x){return working(x,dow,t)});
    if(did==='any')return booked.length<open.length;
    return open.length>0&&!booked.some(function(a){return a.dentist===did});
  });
}
function nextSlot(){for(var i=0;i<21;i++){var d=new Date();d.setDate(d.getDate()+i);var s=slotsFor(iso(d),'any');if(s.length)return {date:iso(d),time:s[0]}}return null}
function openNow(){var n=new Date(),m=n.getHours()*60+n.getMinutes();return n.getDay()!==0&&m>=540&&m<1140}
function onDutyToday(){var dow=new Date().getDay();return S.dentists.filter(function(d){return d.days.indexOf(dow)>-1}).length}
function logNote(a,text){S.notes.unshift({t:Date.now(),to:a.name,text:text});S.notes=S.notes.slice(0,30)}
var first=function(n){return String(n).split(' ')[0]};
var msgReceived=function(a){return 'Hi '+first(a.name)+', we have received your request for '+fmtDate(a.date)+' at '+fmtTime(a.time)+' at '+C.name+' (ref '+a.ref+'). Our team will confirm shortly.'};
var msgConfirmed=function(a){return 'Hi '+first(a.name)+', your appointment on '+fmtDate(a.date)+' at '+fmtTime(a.time)+' is confirmed (ref '+a.ref+'). To change it, reply here or call '+C.phone+'.'};
var msgReminder=function(a){return 'Reminder: '+first(a.name)+', you have an appointment at '+C.name+' on '+fmtDate(a.date)+' at '+fmtTime(a.time)+'. Reply to reschedule.'};
var msgCancelled=function(a){return 'Hi '+first(a.name)+', your appointment on '+fmtDate(a.date)+' at '+fmtTime(a.time)+' (ref '+a.ref+') has been cancelled. Reply to book a new time.'};
var msgMoved=function(a){return 'Hi '+first(a.name)+', your appointment (ref '+a.ref+') has moved to '+fmtDate(a.date)+' at '+fmtTime(a.time)+'. Reply if this does not suit you.'};
